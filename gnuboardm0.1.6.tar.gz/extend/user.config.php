<?php
if (!defined('_GNUBOARD_')) exit; // Unable to access direct pages
?>