<?php
if (!defined('_GNUBOARD_')) exit; // Unable to access direct pages

define('GML_JS_VER',  '171222');
define('GML_CSS_VER', '171222');
?>