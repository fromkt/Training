<div id="ins_ft">
    <strong><?php e__('GNUBOARD M'); ?></strong>
    <p>GPL! OPEN SOURCE GNUBOARD</p>
</div>

</body>
</html>